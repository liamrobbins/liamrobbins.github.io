'''
Hill Dong and Liam Robbins
Mr. Pittman
Period 5 AP CSP
Activity 3.2.7
'''
from scipy import stats
import os.path
import matplotlib.pyplot as dank
import numpy as memes

directory = os.path.dirname(os.path.abspath(__file__))  #set directory

abortionPercentage=[] #initialize list
filename = os.path.join(directory, 'abortion_data.csv')
datafile = open(filename,'r')#open first data file
for line in datafile: 
    try: #try except to auto skip lines without data
        year,abortion,Percentage,birth = line.split(',') #sort variables, we are only interested in 'Percentage'
        abortionPercentage += [float(Percentage)]    #construct data
    except:
        print ("ayyy",line) #debug purposes

violentCrimeRate=[] #intialize list
filename1 = os.path.join(directory, 'crime_data.csv') 
datafile1 = open(filename1,'r')#open second data file
for line in datafile1: #iterate through each line in the file
    try:
        year,population,violentCrime,crimeRate,x = line.split(',')
        violentCrimeRate += [float(crimeRate)]    #construct data
    except:
        print ("kill me", line) #debug purposes

print
print
print
fig, ax = dank.subplots(1,1)
ax.scatter(violentCrimeRate,abortionPercentage,color='red')#make scatterplot
dank.xlim(0,800) #restrict range and domain
dank.ylim(0,450)
dank.xlabel('Crime per 100,000')#labeling
dank.ylabel('Abortions per 1,000')
ax.set_title('Crime and Abortion')

slope, intercept, r_value, p_value, std_err = stats.linregress(violentCrimeRate,abortionPercentage)#properties of the scatterplot we are going to later use to make a line of regression
dank.plot(memes.unique(violentCrimeRate), memes.poly1d(memes.polyfit(violentCrimeRate, abortionPercentage, 1))(memes.unique(violentCrimeRate)))# graphical representation of line of best fit
print "r-squared:", r_value**2 #r squared value
fig.show() #show fig
'''
References used: 
https://docs.scipy.org/doc/scipy-0.15.1/reference/generated/scipy.stats.linregress.html
http://matplotlib.org/users/pyplot_tutorial.html
http://stackoverflow.com/questions/22239691/code-for-line-of-best-fit-of-a-scatter-plot-in-python
'''